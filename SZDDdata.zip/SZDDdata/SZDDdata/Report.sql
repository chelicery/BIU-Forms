﻿CREATE TABLE [dbo].[Report]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[EquipmentID] INT NULL,
	[DateOfReport] DATE NOT NULL,
	[Content] NVARCHAR (50) NOT NULL, 
	[EquipmentsID] INT,
    CONSTRAINT [FK_Report_ToEquipment] FOREIGN KEY ([EquipmentsID]) REFERENCES dbo.Equipment([ID])
	ON DELETE CASCADE,

)
