﻿CREATE TABLE [dbo].[Exams]
(
	[ID] INT NOT NULL PRIMARY KEY,
	[Date_of_exam] DATE NOT NULL,
	[Expire_date] DATE NOT NULL,
	[Exam_type] VARCHAR NULL, 
	[EquipmentID] INT,
	[UserID] INT,
	CONSTRAINT [FK_Exam_toEquipment] FOREIGN KEY ([EquipmentID]) REFERENCES dbo.Equipment([ID])
	ON DELETE CASCADE,
	CONSTRAINT [FK_Exam_toUser] FOREIGN KEY ([UserID]) REFERENCES dbo.Users([ID])
	ON DELETE CASCADE,

)
