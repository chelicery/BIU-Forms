﻿CREATE TABLE [dbo].[Equipment]
(
	[ID] INT NOT NULL PRIMARY KEY,
	[Name] NVARCHAR NOT NULL, 
    [Type] NCHAR(10) NULL, 
    [SerialNumber] INT NULL, 
    [Location] NVARCHAR(50) NULL, 
    [AdditionalInfo] NCHAR(10) NULL,

)
