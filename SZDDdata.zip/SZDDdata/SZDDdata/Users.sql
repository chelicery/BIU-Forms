﻿CREATE TABLE [dbo].[Users] (
    [ID]      INT           NOT NULL,
    [Login]       NVARCHAR (50) NULL,
    [Password]      NVARCHAR (50) NULL,
	[Name]      NVARCHAR (50) NULL,
	[Surname]      NVARCHAR (50) NULL,
	[Grade]      NVARCHAR (50) NULL,
    [DateOfBirth] DATE      NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
)